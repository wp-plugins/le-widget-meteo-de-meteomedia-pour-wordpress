=== MM Weather ===
Contributors: Meteomedia
Donate link: http://www.meteomedia.com
Tags: weather, temperature, forecast, city weather forecast


== Description ==

Display the weather for your city on your sidebar. Select from various layouts and designs

* Select your city code at - http://www.meteomedia.com/weather_centre/cmswxbuttons
* Select from two different backgrounds - a dark background and a light background
* Select between metric or imperial
* Select between just the current conditions OR current conditions and one period of short term data
* Select between a single loction or multiple locations (up to five)
* Locations could include cities, golf courses, ski resorts, schools or parks.


== Installation ==

1. Download the zip file and extract the contents,
2. Upload the folder `mm-weather` to your WP plugin folder `/wp-content/plugins/` directory,
3. Go to Plugins > Plugins, and activate the plugin,
4. Go to Appearance > Widgets, and drag the widget to a sidebar,
5. Enter the city code that you got from http://www.meteomedia.com/weather_centre/cmswxbuttons in the widget's settings menu