=== MM Meteo ===
Collaborateurs: M�t�oM�dia
Tags: m�t�o, temp�rature, pr�visions, pr�visions m�t�o de la ville


== Description ==

Affichez la m�t�o de votre ville sur votre barre lat�rale. Choisissez parmi diff�rentes mises en page et dessins

* D�finissez vos pr�f�rences de widgets au http://www.meteomedia.com/widget-meteo
* Choisissez parmi deux couleurs de police diff�rentes
* Choisissez entre m�trique ou imp�rial
* Choisissez entre un ou plusieurs endroits (jusqu'� six)

== Installation ==

1. T�l�chargez le fichier Zip et acc�dez au contenu
2. T�l�charger le dossier `mm-meteo` dans le r�pertoire  "/ wp-content / plugins / " de votre dossier  plugin WP.
3. Allez Plugins> Plugins et activez le plugin
4. Allez � Apparence> Widgets, et faites glisser le widget vers la barre lat�rale
5. Entrez le ID widget ainsi que le premier code de localisation que vous avez obtenu � partir du http://www.meteomedia.com/widget-meteo dans le menu des param�tres du widget